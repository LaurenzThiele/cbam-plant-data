Free sample: evaluation use only. The full terms below apply to purchased packs.

# CBAM Installation Screening Register — Data Licence and Terms of Use

Version 1.0, 27 October 2026

Licensor: Laurenz Thiele, independent developer ("I", "me").
Contact: laurenz.thiele@gmail.com

By buying, downloading or using a pack of the CBAM Installation Screening Register (the "Data"), you ("you", the licensee) agree to these terms.

## 1. What you get
The Data pack named on your receipt, in the version delivered at purchase (for example 2026.11.1), plus any updates you are entitled to under section 7.

## 2. Licence
I grant you a non-exclusive, non-transferable, perpetual licence to use the Data you received, for one organisation. "One organisation" means one legal entity, including its employees and contractors working on its behalf. A sole trader or freelancer counts as one organisation.

You may:
- use the Data internally for analysis, screening, research and planning;
- use it to advise your own clients, and include results, charts, figures and short extracts (up to 100 rows) in reports and deliverables for them, with the attribution in section 5.

## 3. What you may not do
Without a separate written licence from me, you may not:
- resell, sublicense, share or publish the Data or substantial parts of it, including to your clients as a dataset;
- embed the Data in software, a SaaS service, an API or another data product offered to others;
- remove or alter the attribution or the disclaimer.

## 4. Nature of the Data (please read)
- The Data is **screening and reference information**. Emissions values are **modelled estimates** from third-party sources, not verified, reported or actual emissions.
- It **must not be used** as embedded-emissions data in CBAM declarations or any regulatory filing.
- Default values are reproduced for convenience from Commission Implementing Regulation (EU) 2025/2621 as corrected by (EU) 2026/1740. **The official text prevails** over anything in the Data.
- Gap figures and confidence levels describe how far a modelled estimate is from a default. They are not a statement about any plant's real performance.
- Nothing in the Data is legal, tax, customs or compliance advice.

## 5. Third-party data and attribution
The Data is built from third-party sources, including Climate TRACE (CC BY 4.0), the European Commission's CBAM default values (CC BY 4.0) and Natural Earth (public domain). Their licences continue to apply to the underlying data, and nothing in these terms limits your rights to obtain those sources directly from their publishers. When you use or quote the Data, keep the credit lines in the README and the "Sources & attribution" sheet.

## 6. No warranty
The Data is provided **"as is" and "as available"**. To the fullest extent permitted by law, I give no warranty of any kind, express or implied, including accuracy, completeness, timeliness, fitness for a particular purpose or non-infringement. Third-party sources may contain errors, and I am not responsible for them.

## 7. Updates and availability of sources
- For **12 months from your purchase date**, you may download any **new version of the pack you bought that I release** in that period, at no extra cost.
- Updates are released **at my discretion**, typically when a source publishes a new version. I don't promise any minimum number, frequency or timing of updates.
- An update may **add, change or remove** fields, plants, countries or whole data sources. This can happen if a source changes its data, methodology or licence terms, becomes unavailable, or is discontinued, or if I can no longer lawfully include it.
- If a source stops being available or usable, I may stop including it, or stop updating some or all packs. **This does not entitle you to a refund or compensation.**
- I may discontinue the product at any time. Your licence to the versions already delivered to you continues under these terms.

## 8. Limitation of liability
To the fullest extent permitted by law:
- my total liability arising from the Data or these terms is limited to **the amount you paid for the pack** concerned;
- I am not liable for indirect or consequential loss, lost profit, CBAM certificate costs, penalties, customs or tax consequences, or any decision made using the Data.

Nothing in these terms excludes liability that cannot be excluded by law, such as liability for intent or gross negligence, or mandatory consumer rights.

## 9. Payment, refunds and seller of record
Packs are sold through an online shop acting as merchant of record (the "Shop"), named on your receipt. The Shop's terms of sale apply to payment, taxes and refunds. Because the Data is digital content delivered immediately, refunds are limited to what that policy and mandatory law require.

## 10. Breach
If you breach sections 2 or 3, your licence ends automatically, and you must delete the Data.

## 11. Changes to these terms
I may update these terms for future purchases. The version that applied when you bought a pack continues to apply to that purchase.